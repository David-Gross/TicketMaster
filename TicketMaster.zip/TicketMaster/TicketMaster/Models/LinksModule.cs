﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TicketMaster.Models
{
    public class LinksModule
    {
        //public Self self { get; set; }
        public List<AttractionModel> attractions { get; set; }
        //public List<Venue> venues { get; set; }
        //public First first { get; set; }
        //public Next next { get; set; }
        //public Last last { get; set; }
    }
}
