﻿Tech Assessment for David Gross

Project: Ticketmaster API mobile app for searching attractions and listing events.

Tools: MVC & .Net Core

Packages:	Newtonsoft.JSON
			System.Net.Http
			Microsoft.ASP.Net

Install: bin\Release\net5.0\publish\TicketMaster

To Run:	In browser go to the url shown on the install (i.e. http://localhost:5000)